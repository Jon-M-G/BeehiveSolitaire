package com.example.beehivesolitaire;

import androidx.appcompat.app.AppCompatActivity;

import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.DragEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    String lastClicked = "";
    String[] gardenSlot1 = new String[4];
    String[] gardenSlot2 = new String[4];
    String[] gardenSlot3 = new String[4];
    String[] gardenSlot4 = new String[4];
    String[] gardenSlot5 = new String[4];
    String[] gardenSlot6 = new String[4];
    ArrayList<String> workPile = new ArrayList<>();
    String[] CompletedSets = new String[13];
    ArrayList<String> CardStack = new ArrayList<>();



    public static int find(String[] S,String s1){ //used to find index of a string in a string array
        for (int i = 0; i<S.length; i++){
            if ((S[i]).equals(s1)) {
                return i;

            }
        }
        return -1;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final ImageView garden1 = findViewById(R.id.iv_garden1);
        final ImageView garden2 = findViewById(R.id.iv_garden2);
        final ImageView garden3 = findViewById(R.id.iv_garden3);
        final ImageView garden4 = findViewById(R.id.iv_garden4);
        final ImageView garden5 = findViewById(R.id.iv_garden5);
        final ImageView garden6 = findViewById(R.id.iv_garden6);
        final ImageView stack = findViewById(R.id.iv_stack);
        if (garden1.getDrawable().getConstantState() == getResources().getDrawable(R.drawable.c_2c).getConstantState()){ //change image on imageView
            garden1.setImageResource(R.drawable.c_2d);
        }
        TypedArray images = getResources().obtainTypedArray(R.array.images); // gets the images that are listed in array.xml so it can be iterated
        // draw random cards for the garden
        // use two different deck objects and have one be shuffled and index the pictures based off of the index of the shuffled, drawn card in the
        // un-shuffled deck
        final Deck d1 = new Deck();
        final Deck d2 = new Deck(); //shuffled deck
        d2.Shuffle(); //shuffle the deck





        garden1.setImageResource(images.getResourceId(find(d1.getDeck(),d2.Draw()),-1));
        garden2.setImageResource(images.getResourceId(find(d1.getDeck(),d2.Draw()),-1));
        garden3.setImageResource(images.getResourceId(find(d1.getDeck(),d2.Draw()),-1));
        garden4.setImageResource(images.getResourceId(find(d1.getDeck(),d2.Draw()),-1));
        garden5.setImageResource(images.getResourceId(find(d1.getDeck(),d2.Draw()),-1));
        garden6.setImageResource(images.getResourceId(find(d1.getDeck(),d2.Draw()),-1));

        for (int i = 0; i<10 ; i++){ //Draw 10 cards for the stack
            CardStack.add(d2.Draw());
        } //top of card stack is index 0 bottom is CardStack.length-1


        stack.setImageResource(images.getResourceId(find(d1.getDeck(),CardStack[0]),-1));
        garden1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (lastClicked.equals(""))
                    lastClicked = "garden1";
                else{
                    switch(lastClicked){
                        case "stack":
                            garden1.setImageDrawable(stack.getDrawable());
                            stack.setImageDrawable();
                            break;
                    }
                }


            }
        });
        stack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (lastClicked.equals(""))
                    lastClicked = "stack";

            }
        });






    }
}
